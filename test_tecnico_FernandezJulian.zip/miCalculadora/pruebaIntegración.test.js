const { agregarFn, borrarFn, igualFn } = require('./script.js');

// Crear el elemento input con el id pantalla
const pantalla = document.createElement('input');
pantalla.id = 'pantalla';
// Añadir el elemento al documento
document.body.appendChild(pantalla);

// Crear una variable para guardar el primer resultado
let resultado1 = 0;

test('muestra el resultado de la ecuación (2 + 3)*(4)', () => {
    // Simular el clic en el botón 2
    agregarFn('2');
    // Simular el clic en el botón +
    agregarFn('+');
    // Simular el clic en el botón 3
    agregarFn('3');
    // Simular el clic en el botón = y capturar el resultado =
     igualFn();
     resultado1 = document.getElementById('pantalla').value;
     borrarFn(); // Borrar el valor actual de la pantalla
     //Multiplicar el resultado capturado
     agregarFn(resultado1);
     agregarFn('*');
     agregarFn('4');
     
     // Simular otro clic en la pantalla
     igualFn();
  
    // Esperar que el valor de la pantalla sea 20
    expect(document.getElementById('pantalla').value).toEqual('20');
  });
  