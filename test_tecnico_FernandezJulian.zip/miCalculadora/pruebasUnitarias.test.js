//Probando función suma-realizado para la entrevista
test('probando función suma', () => {
    // Esperar que eval('2+3') sea igual a 5
    expect(eval('2+3')).toBe(5);
});

//test expect().not()
test('10-2 no es 6', () => {
    // Esperar que la prueba pase al verificar que 10-2 no da 6
    expect(eval('10-2')). not.toBe(6);
});

//probando reultados con resultado tipo Float
test('probando función división y resultados decimales', () => {
    // Esperar que eval('5/2') sea igual a 2.5
    expect(eval('5/2')).toBe(2.5);
});


// El test que verifica si la función eval lanza un error
test('La función eval lanza un error al intentar sumar 5 y a', () => {
    // Esperar que la función eval lance un error al calcular '5+a'
    expect(() => eval('5+a')).toThrow();
});
