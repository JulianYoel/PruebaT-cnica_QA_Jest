// Importo las funciones desde el archivo script.js
const { agregarFn, borrarFn, igualFn } = require('./script.js');

// Creo el elemento input con el id pantalla
const pantalla = document.createElement('input');
pantalla.id = 'pantalla';
// Añadir el elemento al documento
document.body.appendChild(pantalla);


//test prueba UI
test('muestra el resultado de sumar 2 y 3', () => {
  // Simular el clic en el botón 2
  agregarFn('2');
  // Simular el clic en el botón +
  agregarFn('+');
  // Simular el clic en el botón 3
  agregarFn('3');
  // Simular el clic en el botón =
  igualFn();
  // Esperar que el valor de la pantalla sea 5
  expect(document.getElementById('pantalla').value).toBe('5');
});

/*  RESOLUCIÓN DEL TEST NO REALIZADO PARA LA ENTREVISTA:
  -se instaló el paquete npm install --save-dev jest-environment-jsdom necesario para usar el entorno jsdom y simular el navegador web
      y configurarlo en el package.json;
  -se instaló Babel mediante el comando npm install --save-dev @babel/core @babel/preset-env babel-jest como transformador de código para
      que Jest soporte la sintaxis de ES6.  
  */