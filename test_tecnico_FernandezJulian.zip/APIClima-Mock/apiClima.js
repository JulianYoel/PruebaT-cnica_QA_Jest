//Doy funcionalidad  función 'transformar'. 
function transformar() {
    // Realizo una solicitud HTTP a la API
    fetch("https://api.open-meteo.com/v1/forecast?latitude=52.52&longitude=13.41&hourly=temperature_2m")
    .then(response => response.json())
    .then(data => {
        // Muestro la temperatura actual en el párrafo con id='clima'
        document.getElementById('clima').innerText = "La temperatura actual es: " + data.hourly.temperature_2m[0] + "°C";
    })
    .catch(error => console.error('Error:', error));
}

//Exporto el módulo para que jest tenga acceso.
module.exports = transformar;