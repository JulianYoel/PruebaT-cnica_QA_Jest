// Importo el módulo que a simular
const transformar = require('./apiClima.js');

// Simulo el módulo
jest.mock('./apiClima.js');

// Ahora 'transformar' es una función simulada
test('Prueba de función transformar', async () => {
  // Configuro la implementación simulada
  transformar.mockResolvedValueOnce("La temperatura actual es: 10°C");

  const clima = await transformar();
  return expect(Promise.resolve(clima)).resolves.toBe('La temperatura actual es: 10°C');
});
